<?php
include("../controller/config.php");
session_start();
$sql="SELECT * FROM user";

$result=mysqli_query($myconn, $sql);

echo '

        <table border=2px;>
            <tr>
                <th>Name</th>
                <th>Username</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Edit</th>
            </tr>
        
        </table>

';

while($fdata=mysqli_fetch_array($result)) {
    
    $id=$fdata['user_id'];
    $name=$fdata['name'];
    $username=$fdata['username'];
    $email=$fdata['email'];
    $phone=$fdata['phone'];
    
    
    echo '
            <table border=1px;>
            <tr>
                <td>'.$name.'</td>
                <td>'.$username.'</td>
                <td>'.$email.'</td>
                <td>'.$phone.'</td>
                <td><a href="update.php?id='.$id.'">Edit</td>
            </tr>
            </table>
            
            
            <a href="../actions/logout.php?logout=true">Logout</a>

';
    
    
}






?>
