<?php
include("../controller/config.php");

$sql="CREATE TABLE IF NOT EXISTS user(
user_id INT(11) NOT NULL auto_increment,
primary key (user_id),
username VARCHAR(255),
email VARCHAR(255),
password VARCHAR(255),
phone INT(11)  )";

$result=mysqli_query($myconn, $sql);

if($result===TRUE) {

    echo 'table created';

}
else {
    
    echo 'failed';
}












?>