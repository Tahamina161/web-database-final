function formvali() {
    
    var namee= document.forms["rform"]["name"].value;
    var username= document.forms["rform"]["uname"].value;
    var password= document.forms["rform"]["password"].value;
    var email= document.forms["rform"]["email"].value;
    var phone= document.forms["rform"]["phone"].value;    
    
    if(namee=="") {
        
        window.alert("Name field Cant be Empty");
        return false;
        
    }
    
    if(username=="") {
        
    window.alert("Username field Cant be Empty");
    return false;
        
    }
    if(password=="") {
        
    window.alert("Password field Cant be Empty");
    return false;
        
    }
        if(email=="") {
        
        window.alert("Email field Cant be Empty");
        return false;
        
    }
    
        if(phone=="") {
        
        window.alert("Name field Cant be Empty");
        return false;
        
    }
    
    //phone verification

    var cphone=phone.length;
    if (cphone != 11) {
        
        window.alert("Phone number must be 11 digits.");
        return false;
        
    }
    
    //Email verification
    
    var cemail= new RegExp("^(?=.*[@])");
    
    if(!cemail.test(email)) {
        
        window.alert("Enter a valid email");
        return false;
        
    }
    
}