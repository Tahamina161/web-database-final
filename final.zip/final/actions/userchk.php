<?php
include("../controller/config.php");
session_start();
$username=$_POST['uname'];
$password=$_POST['password'];
$rule=$_POST['rule'];

$sql="SELECT * FROM user WHERE username='$username' AND password='$password'";
$result=mysqli_query($myconn, $sql);

$count=mysqli_num_rows($result);

if ($count==1) {
    
    if($rule=='student'){
        
        $_SESSION['usr']=$_POST['uname'];
        header("location:../user/list.php?u=$username");
    }
    else if($rule=='teacher') {
        $_SESSION['usr']=$_POST['uname'];
        header("location:../user/list.php?u=$username");
}
    else if($rule=='admin') {
        $_SESSION['usr']=$_POST['uname'];
        header("location:../user/list.php?u=$username");
    }

}
else {
    
    echo 'failed';
}
    


?>