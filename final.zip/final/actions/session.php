<?php

session_start();

$user=$_SESSION['usr'];

if(!isset($_SESSION['usr'])) {
    
    
    header("location:../login.php");
    
    
}







?>