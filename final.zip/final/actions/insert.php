<?php
include("../controller/config.php");

$user=$_POST['name'];
$username=$_POST['uname'];
$email=$_POST['email'];
$password=$_POST['password'];
$phone=$_POST['phone'];
$rule=$_POST['rule'];

$dp=$_FILES['dp']['name'];
$dp_tmp=$_FILES['dp']['tmp_name'];
$dir="../images/".$dp;    
move_uploaded_file($dp_tmp, $dir);


$sql="INSERT INTO user(name, username, email, password, phone, rule, dp) VALUES ('$user','$username','$email','$password','$phone','$rule','$dir')";


$result=mysqli_query($myconn, $sql);

if ($result===TRUE) {

    echo 'uploaded';

}
else {
    
    echo 'failed';
}
    


?>