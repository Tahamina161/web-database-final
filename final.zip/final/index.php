<?

?>

<!DOCTYPE html>
<html>
    <head>
        
        <title>Final exam</title>
        
    </head>
    <body>
        
        
        <a href="login.php">Log In</a>
        <a href="reg.php">Sign up</a>
    
    
    </body>
</html>