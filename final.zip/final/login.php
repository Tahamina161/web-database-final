<?

?>

<!DOCTYPE html>
<html>
    <head>
        
        <title>Final exam</title>
        
    </head>
    <body>
        
        
      <form action="actions/userchk.php" method="POST">
          
          
          Username: <input type="text" name="uname" placeholder="username"><br>
          Password: <input type="password" name="password" placeholder="password"><br>
          
          Rule: <select name="rule">
                    
                    <option value="admin">Admin</option>
                    <option value="student">Student</option>
                    <option value="Teacher">Teacher</option>
          
          </select><br>
          
          
          <input type="submit" value="Sign in">
        
        </form>
    
    
    </body>
</html>