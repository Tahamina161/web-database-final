<?

?>

<!DOCTYPE html>
<html>
    <head>
        <script src="script/function.js" type="text/javascript"></script>
        
        <title>Final exam</title>
        
    </head>
    <body>
        
        
      <form action="actions/insert.php" method="POST" id="rform" onsubmit="return formvali();" enctype="multipart/form-data">
          
          
          Name: <input type="text" name="name" placeholder="full name"><br>
          Username: <input type="text" name="uname" placeholder="username"><br>
          Email: <input type="text" name="email" placeholder="email"><br>
          Password: <input type="password" name="password" placeholder="password"><br>
          Phone: <input type="number" name="phone" placeholder="phone"><br>
          Rule:   <select name="rule">
                    <option value="admin">Admin</option>
                    <option value="student">Student</option>
                    <option value="teacher">Teacher</option>
                  </select>
          <br>
          Profile picture: <input type="file" name="dp"><br>
          <input type="submit" value="Sign up">
        
        </form>
    
    
    </body>
</html>